# Robotic Perception
[![CodeFactor](https://www.codefactor.io/repository/github/nykabhishek/robot-localization-algorithms/badge)](https://www.codefactor.io/repository/github/nykabhishek/robot-localization-algorithms)

Jupyter Notebook implementation of Robot perception algorithms.

Algorithms include:
  - `Monte Carlo Localization`
  - `Kalman Filter`
  - `Extended Kalman filter`
